Provided by Nobiax

This work is under Creative Commons 3.0 Licence.

Absolutely free to use or to modify in personal or commercial work.

You are free:

    * to Share—to copy, distribute and transmit the work, and
    * to Remix—to adapt the work

Under the following conditions:

    * Attribution—You must attribute the work in the manner specified by the author or licensor (but not in any way that suggests that they endorse you or your use of the work.)
    * Share Alike—If you alter, transform, or build upon this work, you may distribute the resulting work only under the same, similar or a compatible license.

With the understanding that:

    * Waiver—Any of the above conditions can be waived if you get permission from the copyright holder.
    * Other Rights—In no way are any of the following rights affected by the license:
          o your fair dealing or fair use rights;
          o the author's moral rights; and
          o rights other persons may have either in the work itself or in how the work is used, such as publicity or 		    privacy rights.
    * Notice—For any reuse or distribution, you must make clear to others the license terms of this work. The best way to do that is with a link to http://creativecommons.org/licenses/by-sa/3.0/


Give me a link, if you can, of the result at nobiax.deviantart.com
