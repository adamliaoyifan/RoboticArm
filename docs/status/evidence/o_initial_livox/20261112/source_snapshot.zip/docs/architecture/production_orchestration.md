# Production Orchestration

This document defines the production loading-cell orchestration contract. The
same state machine and exploration contracts apply in simulation and on
hardware. Adapters may differ by backend; authorization, state progression, and
online map inputs may not.

## Startup Boundary

`WAIT_START` is the initial state. Launch completion, lifecycle activation,
service readiness, sensor readiness, timers, and ordinary `run` / `step`
commands must not authorize robot motion, vacuum changes, or detection.

The only initial authorization event is an explicit operator `start` command.
After it is accepted, the orchestrator establishes the cargo-map session before
prompting for a placed box. User ruling2026-11-12 permits a declared initially
empty ULD to skip initial container exploration, under the source/provenance
contract in real_scenario.md. An undeclared or retained-content ULD still needs
sufficient observation. A reset alone is never an empty-container declaration.
The explicit-start diagnostic driver initializes this declared empty session
through the O owner and has no mandatory portal motion. Optional diagnostic
views remain explicit; normal pickup observation is retained.

For subsequent boxes, prefer qualifying RGB-D or LiDAR observations from normal
post-release exit/return stops; add a collision-checked observation pose only
when relevant coverage is insufficient. A fixed portal pose is not a production
requirement. LiDAR integration requires its actual range/frame/time semantics,
not relabelling Cartesian laser points as optical-Z depth. Sensors share one map
owner and source resolution. Startup and execution authorization stay unchanged.

## Full-operation simulation adapter

`luggage_gazebo` selects `planning_pipeline=joint_operation` explicitly through
its grouped profile. The legacy `frame_runtime` peer graph is a separate
compatibility mechanism, not the complete-operation identity or activation flag.
The new mode composes one O owner, measured optical rays, common placement,
prepare/native services and the bound execution consumer. All model readers use
the same expanded full URDF/SRDF. No automatic startup FJT hold is issued in this
mode. A diagnostic client requires explicit `--start` before map reset, observation
motion, detection or cycle execution. Gazebo spawn output is physics-only; only
measured detector and O outputs populate online planning requests. Legacy G and
segmented selector owners must not coexist with this O composition.

For diagnostic observation repair, `--view-poses` may supply explicit JSON goals
using `diagnostic_observation_poses_v1`, bound to the exact model SHA256 and scene
revision. The runner archives this input. These goals override observation names
only; MoveGroup must still plan and execute each empty-load motion, and actual
settled RGB-D/O evidence must establish visibility. Offline IK or static-state
collision success does not establish a usable view or permit filling unknown
space. Such diagnostic goals are not calibrated real-cell poses.

## Operator Request Correlation

The orchestrator publishes each operator prompt with a generated request ID,
prompt kind, current state, and display text. Prompt messages must not contain
box geometry, pose, identity, dimensions, or simulation truth.

An operator pickup-ready event authorizes one cycle only when it carries the
exact current request ID and the expected schema version. Missing, blank,
stale, duplicate, malformed, or wrong-ID confirmations must not emit motion or
detection effects.

## Pure State Contract

The state reducer is a ROS-free contract. It may consume plain decoded events
and return declarative effects, but it must not call ROS, sleep, read YAML,
lookup TF, inspect Gazebo, or execute motion.

Effects describe work for a node layer, for example `CALL_ACTION`,
`CALL_SERVICE`, `PUBLISH_PROMPT`, and `PUBLISH_STATUS`. Effects that may move
the robot, change vacuum, or trigger detection must mark that capability
explicitly so tests can assert startup and request-correlation safety.

## Required Cycle

The required nominal progression is:

```text
WAIT_START
  -> RESET_CARGO_MAP
  -> EXPLORE_CONTAINER
  -> RETURN_PICK_OBSERVE
  -> WAIT_PICKUP_READY
  -> DETECT
  -> COMPUTE_PLACEMENT
  -> PLAN_PICK
  -> EXEC_PICK
  -> PLAN_PLACE
  -> EXEC_PLACE
  -> COMMIT_AND_VERIFY
  -> RETURN_PICK_OBSERVE
  -> WAIT_PICKUP_READY
```

Every return to `WAIT_PICKUP_READY` must happen after reaching
`pick_observe_pose`. The cargo map persists across placed boxes and is updated
only from live depth integration and explicit placement commits.

## Failure Boundaries

### Bound complete-plan consumer

The independently prepared complete-operation path uses
`JointOperationExecution` as a pure effect/state contract. It requires consumer
identity/digest admission and live start validation before issuing motion. Its
node adapter dispatches each correlated effect once. An `execute_leg` effect
consumes the original frozen timed path, without J6 edits or replanning.

Before carrying, `confirm_attachment` must produce a valid, confirmed measured
attachment from the existing attachment provider. Then `validate_attached_suffix`
checks provider freshness, actual q, actual frozen geometry, current scene,
certificate liveness and intended placement under the actual grasp. A mismatch
may pass only through that actual-geometry revalidation; refusal enters a carry
fault for bounded repair/recovery. It must not rewrite the prediction or release.

Before retreat, release confirmation must precede application of the released
box as a world obstacle and retreat validation. A failed release confirmation
retains payload responsibility. A confirmed release followed by blocked retreat
stops motion. Cancellation during controller execution waits for its terminal
result; transport errors alone cannot establish that motion has stopped.
Duplicate/stale callbacks issue no new effects.

This consumer has no ROS, global planner or vacuum dependency. Production node
adoption must implement and verify its effects against the native scene and
controller; pure consumer tests do not certify that adoption. Existing startup,
operator correlation and map ownership requirements apply to the complete-plan
path as well as the nominal cycle above.

`NativeOperationRevalidationPort` supplies the read-only native portion of
these validation effects. It accepts only the original canonical six-leg chain
and exact pick/pick/carry/carry/carry/retreat phases. Every current capture must
bind the same scene revision, model, geometry and map revision, with explicit
six-joint winding consistent with both the original leg start and the captured
robot state. The current world's owned payload must actually match the admitted
load phase; reconstructing private phase scenes cannot hide a missing, duplicate
or changed live attachment. Unrelated obstacles survive.

The port checks original release FK under the actual attachment against the
bound nominal box target, using the existing endpoint tolerances. The configured
release gap determines a predicted settled box pose from that grasp; this is not
an observed placement and cannot authorize an OCC commit. Only numerical pose
equivalence from the operation contract canonicalizes floating representation.
The caller must explicitly provide issued-certificate liveness, current source /
attachment freshness, whole-footprint actual-contact admission while carrying,
and current settled-box occupancy admission. A predicted grasp approval cannot
stand in for actual-contact approval after an attachment change. Each must
return literal true; absent, stale, exceptional or incomplete answers refuse.
Certificate and source liveness are checked again after native validation.

The native request retains original knots and controller-interpolated samples
of every remaining leg in full private phase scenes, including the released
world obstacle. Compatible changed geometry can pass without global replanning;
a target miss, collision, deadline or identity change yields no accepted receipt.
When capture is enabled, a native suffix refusal also records a bounded summary
of failed leg, phase-scene index, first invalid sample/TCP and contact pairs with
their matched world/attached geometry. Preserve the full request/response CDR.
The summary reports model collisions; object names and contact enums establish
neither physical contact nor cargo ownership and authorize no obstacle removal.
The receipt retains the original plan/certificate binding plus a separate native
validation digest. The port has no controller, vacuum, planner, scene-write or
map-write capability. Production adapters still need to implement the required
owner callbacks and consume its receipts before actual controller submission;
native fixture/consumer tests do not certify that adoption.

The preparation owner retains a bounded process-local issuance registry only
after the final complete response has been captured. Its read-only
`/joint_operation/check_prepared` service decodes the submitted plan against
the independently retained identity/digest. An arbitrary nonempty certificate
field is not issuance evidence. Checks do not renew retention. Restart, expiry,
capacity eviction or a successfully replaced plan makes the old plan fail
liveness. Failed preparation or response capture cannot issue a plan. The
default retention is 16 plans / 16 MiB canonical payload / 300 monotonic seconds,
with explicit node parameters; these are storage limits, not geometric or
observation thresholds. A liveness success still requires every current-source,
actual-contact, occupancy and native suffix gate before controller submission.

Production preparation first retains its exact measured acquisition through the
perception owner. Candidate quality queries use the independent
`EvaluateFrozenSuctionV2` service; the existing current-frame service is unchanged.
Later camera frames cannot substitute samples or replace the retained acquisition
identity. After certification and the final full-scene read, preparation checks
the same non-renewing owner token, live six-joint start and pinned confirmed OCC.
Unavailable, revoked, expired or changed-model evidence cannot issue PLAN_READY.

Issuance stores the immutable contact binding with the exact issued plan and
counts its metadata in the bounded byte budget. A duplicate publication cannot
replace or drop that binding. The read-only issuance check returns this owner
provenance, independently of the submitted plan. It still does not assert
observation liveness or physical seal; execution must check the actual perception
and attachment owners before native/controller admission. A stored binding is
not a new view, a pose correction or a reason to skip any execution gate.

The original O source is also retained independently with the issued plan:
epoch, map/observed revisions, acquisition stamp, hull/config digests, clock,
validity generation and full content digest. CheckPreparedOperationV2 returns
typed OperationMapSourceV2; duplicate issuance cannot replace or drop it and
its bytes count against retention. The default preparation root reads one O
lease for both surface and volume and rechecks a fresh lease before issuance.
Changed map content needs fresh native validation before execution;
changed epoch/config/model/hull invalidate the original source association.
Legacy explicit G has an unbound O source and cannot enter an O-only consumer.

A later O lease remains current for an original source when epoch, validity
generation, hull/config digests, clock and map_revision match, observation
revision and acquisition stamp have not gone backwards, and the owner's live
lease is valid and within the configured age limit. Repeated observations alone
do not require recertification. O currently advances map_revision on every
changed cell value, including probability changes; this conservatively triggers
recertification even when the collision classification remains unchanged.
Each page of one lease still requires its entire exact snapshot identity.
Retain the original source acquisition stamp and provenance; record the later
lease separately. Global observation activity does not renew the age of an
unobserved region or establish per-region freshness. Regional age admission
requires spatial coverage evidence and is not supplied by this version check.

The ULD static-world premise is conditional: during a normal operation only the
current cargo moves. Contact by the robot or current cargo can displace other
cargo and invalidates that premise. A collision/protective-stop indication,
execution fault, or observed displacement must revoke continuation under the
old world assumption. Request stop and retain motion ownership until a real
terminal result; preserve suction if still carrying. Do not automatically
resume the original suffix or reverse it as a recovery motion. Recovery needs
fresh observation and a separately admitted plan using the actual fixed
attachment (if still sealed). A successful geometric check or absence of an
error message does not establish absence of physical contact.

Any consumer of a cycle-frozen background map must state how that premise is
monitored, including signal ownership, timestamps, loss of signal and occluded
cargo. Robot current or torque availability cannot be assumed, nor may contact
thresholds be invented. The static-world premise alone does not authorize
discarding new O occupancy, carving out a planned cargo footprint, or ignoring
an occupied voxel. Until the monitoring and current-cargo association policy
are admitted, the current-map/native admission rules above remain in force.

The strict operation motion transport submits one original timed leg through
MoveIt ExecuteTrajectory. It retains every joint coordinate (including full
turns), timestamp, derivative and effort value. A native receipt must bind the
original identity/certificate/index and actual carry geometry; source liveness
and fresh measured raw joint coordinates are checked again immediately before
submission. SUCCEEDED alone is insufficient: MoveIt SUCCESS and a fresh measured
endpoint within the owner's explicit joint tolerance are also required.

The production owner must share one motion lock with every other motion entry
point. Pending acceptance, timeout, cancellation acknowledgement and transport
exceptions do not prove a stopped controller. The transport retains that lock
until a real rejection or terminal result is consumed, cancels late accepted
goals after a stop request, and refuses overlapping submissions. Uncertain
transport has no force-clear shortcut. This port has no vacuum, planner, scene
or map writes; fixture coverage does not certify production owner adoption.

`MotionPlannerNode` now owns one `MotionOwnership` instance for its actual
PlanMotion, PlanMotionV2 and GoToRobotPose callbacks. Busy callbacks abort before
entering their planner/controller work. Legacy MoveGroup, ExecuteTrajectory and
FJT clients explicitly track dispatch, acceptance and terminal result through
this owner. A handler returning or throwing cannot release an unresolved goal;
late accepted goals are cancelled, with ownership held until terminal status.
Unknown or nonterminal results cannot authorize a legacy fallback. Public result
futures are completed only after the owner consumes the same result, so executor
callback ordering cannot overlap consecutive submissions.
The node's action-cancel callback stops only the session bound to that exact
ServerGoalHandle. It cancels accepted inner goals, remembers the stop for late
acceptance and prevents fallback submissions; a pending cancel cannot release
the session. A terminal inner result still waits for the owning callback to
finish. An already cancelled outer goal never enters its planning/controller
body. Cancelling a stale or different goal cannot stop the current owner.

A complete-operation adapter must acquire this same owner's session across all
legs and vacuum/event barriers, and give its separate `motion_lock` to the strict
transport per leg. It must finish the session only after the strict transport
consumes terminal status and releases that lock. The session excludes legacy
requests even between legs. This process-local owner does not arbitrate unrelated
nodes or direct controller clients; the production launch/driver must route every
motion entry through the owning node. Complete-operation and driver adoption
remain required; ownership wiring alone is not a completed execution chain.

Before suction, input contact xyz is a proposal on the observed box face. The
planner may select another fully supported contact and directed attitude to
serve the target placement, but must return the final pick pose, J6 and bound
complete trajectories before motion. After suction the rigid box/tool relation
is fixed. Rotating the arm moves that fixed box and tool together; it never
selects another contact or edits the issued joint trajectories.

For the user-confirmed stationary pre-seal box, the complete-operation
`StationaryOperationAttachmentPort` qualifies the actual VacuumCommandV2
request/response against the original issued plan and perception-owner token.
It requires current nonrenewing retention plus an actual full-footprint and
surface-quality result under the returned actual G. The existing measured
attachment provider has a separate `record_stationary_attachment` entry for
this qualified source; ordinary `record_attachment` still requires zero skew.
The record acquisition stamp remains the original box stamp. Its independent
StationaryAttachmentEvidence binds the later actual TCP confirmation stamp,
both measured poses, every typed request/response field, original frozen binding, actual
footprint result, conservative geometry, box identity and generation. Neither
storage retention nor confirmation time renews the existing acquisition age.
A valid stationary seal cannot be overwritten through either provider entry;
a replay after invalidation cannot revive it. This read-only qualification
layer does not command vacuum, certify a changed grasp's remaining path or
complete production execution; those event and native admission gates remain.
Raw CDR is retained for replay; stable receipt hashes use canonical typed ROS
fields because DDS alignment padding can change for identical messages.

The vacuum boundary must read the measured TCP again after the actuator
confirms sealing; a pose read before a blocking seal wait is not confirmation
evidence. Preserve the original stationary box timestamp and the new TCP
timestamp. If sealing succeeded but this later measurement cannot qualify,
report physical success with `has_measured_attachment=false` and the explicit
`SEALED_ATTACHMENT_MEASUREMENT_UNQUALIFIED` diagnostic. Keep vacuum enabled;
the operation owner must refuse carrying and retain the unresolved payload.
Do not detach or invent a measured relation to turn this into a clean failure.

Actual full-footprint contact revalidation may use the same box's retained,
frozen pre-grasp RGB-D top observation and the measured attachment relation.
Its acquisition frame/pose remain fixed; a new wrist-camera frame must not
replace this evidence. Invalidated box identity, model or observation refuses
continuation. Re-evaluate the actual footprint against those measured samples;
the original planned-grasp quality verdict is not sufficient after an offset.

Failure handling must distinguish pre-pick, carrying, release, verification,
abort, and recovery boundaries.

Before payload attachment, failures return to a non-moving wait or explicit
retry/recovery boundary. While carrying, failures transition to a carry fault
and preserve vacuum until an explicit recovery confirms payload release.
Placement commits are idempotent and must not double-count attempts.

## Exploration Boundary

Exploration policy contracts are immutable, serializable, ROS-free plain data.
Policies may propose or score candidate views, but they must not execute
motion, mutate the map, read TF, or receive ground truth.

Exploration integration must correlate the settled view request ID, source
acquisition stamp, expected map revision, and container geometry hash. Stale,
ambiguous, repeated, or mismatched view integration fails closed.

Simulation evaluation may read Gazebo truth only offline or in test/eval scope.
The online production path must not branch on `sim_mode`, consume GT, or use a
fake production success path. Drivers that call production services
(`DetectLuggage`, `ComputePlacement`, cargo-map commit, MoveIt) are in that
online path even when they live under `luggage_gazebo`. Catalog size,
`GetCurrentBox`, and unverified planned poses are GT for this rule. The
defect catalog is [real_scenario.md](real_scenario.md).
