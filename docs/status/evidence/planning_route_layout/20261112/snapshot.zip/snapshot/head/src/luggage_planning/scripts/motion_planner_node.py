#!/usr/bin/env python3
"""PlanMotion action server + GoToRobotPose (ROS 2 Humble port).

One segment per PlanMotion goal; the eval driver loops the four pick
segments itself. Feedback walks planning -> executing -> settling
(``settle_criterion.SettleTracker`` on /joint_states) so the caller can
wait for geometry_ok to recover before the next segment.

GoToRobotPose resolves a named pose from robot_poses YAML to joint angles
and sends them via plain FJT (no MoveIt; that is what observe_pose_hold
does, and named poses are joint-space anyway). Pose name ``current`` /
``here`` stays at live /joint_states (no FJT). Site launch uses
``robot_poses.site.yaml``; do not send simulation ``pickup_observe``.

Keeps the original node name per docs/plans/closed_loop_pick_retreat_nodes.md.
"""

from __future__ import division

import json
import math
import os
import threading
import time

import rclpy
from action_msgs.msg import GoalStatus
from builtin_interfaces.msg import Duration
from control_msgs.action import FollowJointTrajectory
from moveit_msgs.msg import PlanningSceneComponents
from rclpy.action import ActionServer, CancelResponse, GoalResponse
from rclpy.callback_groups import ReentrantCallbackGroup
from rclpy.executors import ExternalShutdownException, MultiThreadedExecutor
from rclpy.node import Node
from rclpy.qos import DurabilityPolicy, QoSProfile, ReliabilityPolicy
from sensor_msgs.msg import Image, JointState, PointCloud2
from std_msgs.msg import String
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint

from luggage_description.scene_tf_config_utils import (
    _point_in_container_link,
    container_inner_floor_z,
    load_scene_tf_config,
    origin_in_world,
    resolve_scene_tf_config_path,
    xyz_world_to_base_link,
)
from luggage_msgs.action import GoToRobotPose, PlanMotion, PlanMotionV2
from luggage_msgs.srv import ProbeMotionSegment, ProbeMotionSegmentV2
from luggage_planning.debug_capture import write_failure_capture
from luggage_planning.atlas_runtime import (
    PARAM_SPEC,
    apply_query_semantics,
    apply_ros_overrides,
    atlas_seeds_for_query,
    compute_reachability_scene_hash,
    compute_scene_tf_hash,
    load_atlas_runtime_for_scene,
    load_runtime_atlas,
)
from luggage_planning.urdf_identity import UrdfIdentity
from luggage_planning.motion_boundary import robot_traj_to_dict, write_boundary_dump
from luggage_planning.motion_executor import MotionExecutor, _wrap_near
from luggage_planning.motion_ownership import MotionOwnership, OwnedActionClient, run_legacy_motion
from luggage_planning.named_robot_poses import (
    JOINTS,
    load_poses_config,
    plan_goto_joints,
    resolve_pose_name,
)
from luggage_planning.occupancy_place_paths import (
    OccupancyMismatch,
    OccupancySnapshot,
    exempt_footprint_locals,
    occupancy_collision_boxes,
    load_selector_weights,
    resolve_payload_wdh,
)
from luggage_planning.waypoint_generator import tool_down_yaw
from luggage_planning.current_box_payload import (
    measured_from_current_box_json,
)
from luggage_planning.planning_scene_client import (
    PlanningSceneClient,
    summarize_planning_scene,
)
from luggage_planning.ros_clock_wait import ClockTimeout, wait_event
from luggage_planning.settle_criterion import SettleTracker


def occupancy_scope(names_csv, segment_name):
    """True when ``segment_name`` is inside the occupancy-injection scope.

    ``names_csv`` is a comma-separated segment list; ``*`` widens it to
    every segment (the placement.md contract: every place-motion planner
    queries current cargo occupancy). Narrow it to ``"transit,traverse"``
    to restore the carry-only scope.
    """
    names = {part.strip() for part in str(names_csv or "").split(",")
             if part.strip()}
    return "*" in names or str(segment_name) in names


# Cross-call caches for the atlas seed chain (URDF parse + tcp path).
_ATLAS_CACHE = {}


class MotionPlannerNode(Node):

    def __init__(self, **node_options):
        super().__init__("motion_planner", **node_options)
        self._group = ReentrantCallbackGroup()
        self._motion_owner = MotionOwnership()

        self.declare_parameter("robot_poses_config", "")
        self.declare_parameter("default_observe_pose", "current")
        self.declare_parameter("execute_timeout", 90.0)
        self.declare_parameter("planning_time", 5.0)
        self.declare_parameter("num_planning_attempts", 10)
        self.declare_parameter("planner_id", "RRTConnect")
        self.declare_parameter("cartesian_max_step", 0.01)
        self.declare_parameter("cartesian_min_fraction", 0.95)
        # Refuse a cartesian solution that unwinds the arm through a
        # near-singular reconfiguration instead of executing it; see
        # motion_executor._CARTESIAN_EXCURSION_RAD_PER_M for the measurement.
        self.declare_parameter("cartesian_excursion_rad_per_m", 3.0)
        # Deterministic joint re-solve when a no-fallback cartesian leg
        # (insert/descend/retreat) is rejected by the excursion gate or a
        # sub-threshold fraction: offline refine from the live joints, then
        # the executor re-checks the SAME excursion bar (fail-closed).
        self.declare_parameter("cartesian_joint_fallback", True)
        # Wrist-only excursion on insert/descend: rotate onto the goal
        # heading in place, then re-run the descent (see
        # motion_executor._align_then_retry).
        self.declare_parameter("align_retry_enabled", True)
        # Dump-only: closest approach of elfin_joint5 to k*pi.
        self.declare_parameter("wrist_singularity_margin_rad", 0.50)
        # Dump-only: max per-joint |seed-goal| on pose_target IK.
        self.declare_parameter("pose_target_max_joint_delta_rad", 1.50)
        # Dump-only j6 travel. Not a refuse gate.
        self.declare_parameter("j6_rotation_limit_rad", 2.50)
        # Kept so older launches still parse. No longer a refuse opt-out.
        self.declare_parameter("wrist_free_segments", "")
        # keep_tool_down: suction normal within this many radians of
        # world -Z. Yaw about that axis is free. j5 and j6 are not gated.
        self.declare_parameter("tool_down_abs_tol", 0.05)
        self.declare_parameter("velocity_scaling", 0.3)
        self.declare_parameter("acceleration_scaling", 0.3)
        # Settle gate between segments.
        self.declare_parameter("settle_vel_tol", 0.02)
        self.declare_parameter("settle_hold_time", 0.5)
        self.declare_parameter("settle_timeout", 8.0)
        # Cap on GoToRobotPose FJT time_from_start. Actual duration is
        # min(cap, max_joint_delta / named_pose_max_vel), at least 1 s.
        self.declare_parameter("named_pose_duration", 4.0)
        self.declare_parameter("named_pose_max_vel", 1.0)
        # Must match elfin_trajectory_executor action_name (Jazzy real launch).
        self.declare_parameter(
            "fjt_action", "/elfin_arm_controller/follow_joint_trajectory")
        self.declare_parameter("scene_tf_config", "")
        # Conservative fallback envelope ONLY: the occupancy sweep prefers
        # the perception-measured geometry synced onto /luggage/current_box
        # (privilege boundary — no GT spawn size on the chain).
        self.declare_parameter("payload_width", 0.55)
        self.declare_parameter("payload_depth", 0.40)
        self.declare_parameter("payload_height", 0.25)
        weights = load_selector_weights()
        self.declare_parameter("inflate_m", float(weights["inflate_m"]))
        self.declare_parameter("arm_radius_m", float(weights["arm_radius_m"]))
        self.declare_parameter("max_occ_objects", int(weights["max_occ_objects"]))
        self.declare_parameter(
            "occupancy_freshness_s",
            float(weights.get("occupancy_freshness_s", 0.0)))
        # Which segments get cargo occupancy injected: "*" (default, the
        # placement.md "place motion through occupancy" contract) or a
        # comma list ("transit,traverse" restores the carry-only scope).
        self.declare_parameter("occupancy_segments", "*")
        # Extra relief on top of arm_radius + inflate for the landing
        # footprint exemption; tune in sim without code changes.
        self.declare_parameter("occupancy_exempt_margin_m", 0.0)
        # Failure-time occ/cloud/depth capture (never blocks motion).
        self.declare_parameter("debug_capture", True)
        # Reachability-atlas IK seed chain (shared yaml; overridable).
        self.declare_parameter("atlas_runtime_config", "")
        scene_path = str(self.get_parameter("scene_tf_config").value or "")
        scene_path = resolve_scene_tf_config_path(scene_path or None)
        atlas_cfg = load_atlas_runtime_for_scene(
            scene_path,
            str(self.get_parameter("atlas_runtime_config").value) or None)
        for ros_name, _path, _cast in PARAM_SPEC:
            default = atlas_cfg
            for key in _path:
                default = default[key]
            self.declare_parameter(ros_name, default)
        apply_ros_overrides(self, atlas_cfg)
        self._atlas_cfg = atlas_cfg
        self._atlas_cache = {}
        self._urdf_identity = UrdfIdentity(self)
        if self._atlas_cfg.get("enabled"):
            self._urdf_identity.start()

        self._scene = load_scene_tf_config(scene_path)
        self._scene_tf_hash = compute_scene_tf_hash(scene_path)
        self._reachability_scene_hash = compute_reachability_scene_hash(
            scene_path)
        self._surface_2d = None
        self._surface_recv = None
        self._payload_measured = None
        self._payload_recv = None
        self._payload_source = "static_default"
        self._payload_wdh_current = []
        self._injected_ids = []
        map_qos = QoSProfile(
            depth=1, reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self.create_subscription(
            String, "/luggage/cargo_map/surface_2d",
            self._on_surface, map_qos, callback_group=self._group)
        self.create_subscription(
            String, "/luggage/current_box", self._on_current_box, map_qos,
            callback_group=self._group)
        # Failure-capture caches: raw messages only, decoded at dump time.
        # The semantic cloud feeds the cargo map (occupancy provenance);
        # the preprocessed depth is the sensor frame underneath it.
        self._cap_cloud = None
        self._cap_cloud_recv = None
        self._cap_depth = None
        self._cap_depth_recv = None
        if bool(self.get_parameter("debug_capture").value):
            cloud_qos = QoSProfile(
                depth=2, reliability=ReliabilityPolicy.BEST_EFFORT,
                durability=DurabilityPolicy.VOLATILE)
            self.create_subscription(
                PointCloud2, "/luggage/semantic/cargo_points_untracked",
                self._on_cap_cloud, cloud_qos, callback_group=self._group)
            self.create_subscription(
                Image, "/luggage/preprocessed/camera/depth/image",
                self._on_cap_depth, 1, callback_group=self._group)
        self._scene_client = PlanningSceneClient(
            self, callback_group=self._group)

        self._joint_state = None
        self._joint_lock = threading.Lock()
        self.create_subscription(
            JointState, "/joint_states", self._on_joint_state, 10,
            callback_group=self._group)

        self._executor_client = MotionExecutor(
            self,
            motion_owner=self._motion_owner,
            allowed_planning_time=float(
                self.get_parameter("planning_time").value),
            num_planning_attempts=int(
                self.get_parameter("num_planning_attempts").value),
            planner_id=str(self.get_parameter("planner_id").value),
            cartesian_max_step=float(
                self.get_parameter("cartesian_max_step").value),
            velocity_scaling=float(
                self.get_parameter("velocity_scaling").value),
            acceleration_scaling=float(
                self.get_parameter("acceleration_scaling").value),
            cartesian_min_fraction=float(
                self.get_parameter("cartesian_min_fraction").value),
            cartesian_excursion_rad_per_m=float(
                self.get_parameter("cartesian_excursion_rad_per_m").value),
            wrist_singularity_margin_rad=float(
                self.get_parameter("wrist_singularity_margin_rad").value),
            wrist_free_segments={
                part.strip() for part in str(
                    self.get_parameter("wrist_free_segments").value
                    or "").split(",") if part.strip()},
            pose_target_max_joint_delta_rad=float(
                self.get_parameter("pose_target_max_joint_delta_rad").value),
            j6_rotation_limit_rad=float(
                self.get_parameter("j6_rotation_limit_rad").value),
            tool_down_abs_tol=float(
                self.get_parameter("tool_down_abs_tol").value),
            atlas_seed_provider=self._atlas_seed_provider,
            atlas_mode=str(self._atlas_cfg["motion"].get(
                "mode", "miss-retry")),
            atlas_max_seeds=int(self._atlas_cfg["motion"].get(
                "max_seeds", 3)),
            atlas_fk_verify_tol_m=float(self._atlas_cfg["motion"].get(
                "fk_verify_tol_m", 0.03)),
            atlas_submit_mode=str(self._atlas_cfg["motion"].get(
                "submit_mode", "reseed")),
            fk_verifier=self._verify_tcp,
            cartesian_joint_fallback=(
                self._cartesian_fallback_provider
                if bool(self.get_parameter("cartesian_joint_fallback").value)
                else None),
            align_retry_enabled=bool(
                self.get_parameter("align_retry_enabled").value),
        )
        self._fjt = rclpy.action.ActionClient(
            self, FollowJointTrajectory,
            str(self.get_parameter("fjt_action").value),
            callback_group=self._group)
        self._fjt = OwnedActionClient(self._fjt, self._motion_owner,
            str(self.get_parameter("fjt_action").value))

        self._plan_action = ActionServer(
            self, PlanMotion, "/motion_planner/plan_motion",
            execute_callback=self._execute_plan_motion,
            goal_callback=self._accept_goal,
            cancel_callback=self._accept_cancel,
            callback_group=self._group)
        self._pose_action = ActionServer(
            self, GoToRobotPose, "/motion_planner/go_to_robot_pose",
            execute_callback=self._execute_goto_pose,
            goal_callback=self._accept_goal,
            cancel_callback=self._accept_cancel,
            callback_group=self._group)
        # Plan-only reachability probe (candidate selection, gate C1):
        # IK + raw Cartesian fraction; never moves the arm.
        self._probe_service = self.create_service(
            ProbeMotionSegment, "/motion_planner/probe_motion_segment",
            self._handle_probe_segment, callback_group=self._group)
        self._probe_v2_service = self.create_service(
            ProbeMotionSegmentV2, "/motion_planner/probe_motion_segment_v2",
            self._handle_probe_segment_v2, callback_group=self._group)
        self._plan_v2_action = ActionServer(
            self, PlanMotionV2, "/motion_planner/plan_motion_v2",
            execute_callback=self._execute_plan_motion_v2,
            goal_callback=self._accept_goal,
            cancel_callback=self._accept_cancel,
            callback_group=self._group)
        latch = QoSProfile(
            depth=1, reliability=ReliabilityPolicy.RELIABLE,
            durability=DurabilityPolicy.TRANSIENT_LOCAL)
        self._boundary_pub = self.create_publisher(
            String, "/motion_planner/last_boundary", latch)

        # ST09 F21: identity heartbeat + peer readiness. Motion effects
        # (PlanMotion/PlanMotionV2 execution, GoToRobotPose FJT dispatch)
        # are gated below; off = legacy byte-identical.
        self.declare_parameter("frame_runtime", False)
        self.declare_parameter("frame_identity_json", "")
        self.declare_parameter("frame_peers", "")
        self._frame_runtime = None
        if bool(self.get_parameter("frame_runtime").value):
            import sys as _sys
            from luggage_description.ros_frame_bindings.runtime import (
                node_runtime_from_params)
            self._frame_runtime = node_runtime_from_params(
                self,
                resolved_config={
                    "scene_tf_config": str(
                        self.get_parameter("scene_tf_config").value or ""),
                    "velocity_scaling": float(
                        self.get_parameter("velocity_scaling").value),
                    "acceleration_scaling": float(
                        self.get_parameter("acceleration_scaling").value),
                    "atlas_runtime_config": str(
                        self.get_parameter("atlas_runtime_config").value or ""),
                },
                modules=[(_sys.modules["__main__"], "module", "application")],
                package_names=["luggage_planning"])

        # Do not wait_for_server here: __init__ runs before the executor
        # spins, so discovery of /move_action always times out and the
        # node sits 60 s before advertising PlanMotion. execute_callback
        # already calls wait_ready(15s) per goal.
        self.get_logger().info(
            "motion_planner up (move_group probed on first PlanMotion)")

    # ------------------------------------------------------------------
    # shared plumbing

    def _accept_goal(self, goal_request):
        return GoalResponse.ACCEPT

    def _accept_cancel(self, goal_handle):
        self._motion_owner.request_stop(goal_handle)
        return CancelResponse.ACCEPT

    def _on_surface(self, msg):
        try:
            surface = json.loads(msg.data)
        except ValueError:
            return
        if isinstance(surface, dict) and "height" in surface:
            self._surface_2d = surface
            self._surface_recv = time.time()

    def _on_current_box(self, msg):
        measured = measured_from_current_box_json(msg.data)
        if measured is not None:
            self._payload_measured = measured
            self._payload_recv = time.time()

    def _on_cap_cloud(self, msg):
        self._cap_cloud = msg
        self._cap_cloud_recv = time.time()

    def _on_cap_depth(self, msg):
        self._cap_depth = msg
        self._cap_depth_recv = time.time()

    def _world_to_map(self, xyz):
        base = xyz_world_to_base_link(self._scene, xyz)
        return _point_in_container_link(base, self._scene)

    def _atlas_seed_provider(self, pose):
        """Executor callback: atlas IK seeds for one target pose (or None).

        Frame math stays on the node (the executor is frame-agnostic):
        world -> container_link through the live scene_tf, plus the
        configured query offset for real-machine compensation.
        """
        motion = self._atlas_cfg.get("motion") or {}
        if not (self._atlas_cfg.get("enabled")
                and motion.get("enabled", True)):
            return None
        wdh = self._payload_wdh()
        self._urdf_identity.poll()
        urdf_hash = (
            self._urdf_identity.hash if self._urdf_identity.ready else "")
        key = (tuple(round(float(v), 4) for v in wdh),
               self._reachability_scene_hash, self._scene_tf_hash, urdf_hash)
        if key not in self._atlas_cache:
            # box_size is the payload wdh (key[0]); the whole cache key is
            # not a size list. Passing it made resolve_atlas_files float()
            # the size tuple and every seed query die as no_seeds
            # (2026-10-12 yaw180 run, three identical traverse failures).
            self._atlas_cache[key] = load_runtime_atlas(
                self._atlas_cfg, box_size=list(key[0]),
                scene_tf_hash=self._scene_tf_hash,
                urdf_hash=urdf_hash,
                reachability_scene_hash=self._reachability_scene_hash)[0]
        atlas = self._atlas_cache[key]
        if atlas is None:
            return None
        # Query-layer semantics: floor re-anchoring matters here too -- the
        # 1540/smoke1 class of slot-contact targets lands in the iz1 cell
        # whose sampled centre clips the floor, which would starve the seed
        # query of its own cell and force the neighbour fallback every time.
        atlas = apply_query_semantics(
            atlas, self._atlas_cfg,
            floor_z=container_inner_floor_z(self._scene),
            box_height=float(wdh[2]))
        xyz = self._world_to_map([
            float(pose.position.x), float(pose.position.y),
            float(pose.position.z)])
        # ST06/F16 seed side: the atlas bins are DIRECTED container-frame
        # tool yaws, so the world-frame tool yaw must be re-expressed about
        # container +Z before any bin snap (a raw world yaw would name the
        # wrong branch on a rotated scene).
        yaw = self._container_tool_yaw(pose.orientation)
        from luggage_description.frame_contracts import ContractError
        from luggage_description.scene_tf_config_utils import base_in_world
        from luggage_description.scene_tf_publisher import rpy_to_quaternion
        from luggage_planning.motion_frame_contracts import (
            framed_query_offset, lift_vector,
        )
        origin, rpy = origin_in_world(self._scene)
        container_quat = rpy_to_quaternion(rpy)
        _base_origin, base_rpy = base_in_world(self._scene)
        try:
            offset = framed_query_offset(
                self._atlas_cfg.get("query_offset") or (0.0, 0.0, 0.0),
                motion.get("query_offset_frame", "container_link"),
                container_quat, rpy_to_quaternion(base_rpy))
        except ContractError:
            return None
        found = atlas_seeds_for_query(
            atlas, xyz[0], xyz[1], xyz[2], yaw,
            seed_set=str(motion.get("seed_set", "transit")),
            max_seeds=int(motion.get("max_seeds", 3)),
            query_offset=offset)
        if found.get("seeds") and motion.get("refine", True):
            found["refined"] = True
            # The GT attach hangs the box ~5 mm below + ~8 mm lateral to
            # the suction frame (1540 evidence), so a slot-contact target
            # is ~3.5 mm INSIDE the floor as a MoveIt state. Lift the
            # refine target for in-container goals by the configured
            # compensation; the descend leg's own touch logic finishes.
            lift = float(motion.get("target_z_lift_m", 0.008))
            inside = self._target_in_container(xyz)
            try:
                lift_xyz = lift_vector(lift, container_quat) if inside else (0.0, 0.0, 0.0)
            except ContractError:
                return None
            found["target_z_lift_m"] = lift if inside else 0.0
            found["lift_xyz"] = list(lift_xyz)
            # Also refine the live arm state: a different branch family
            # sweeps a different hull corridor (the 1838 transit path came
            # from the current-joints family, not the atlas family), and
            # the executor tries every FK-verified goal in turn.
            live = self._live_arm_joints()
            seeds = list(found["seeds"])
            if live and all(
                    any(abs(a - b) > 0.05 for a, b in zip(live, seed))
                    for seed in seeds):
                seeds.append(live)
            found["seeds"] = self._refine_atlas_seeds(
                pose, seeds, lift if inside else 0.0, lift_xyz=found.get("lift_xyz"))
        return found

    def _container_tool_yaw(self, quat):
        """Directed tool yaw about container +Z from a world orientation.

        ``tool_down_yaw`` names the yaw about the world Z axis; the atlas
        bins are container-frame, so the container's own yaw in world is
        removed before the snap. Horizontal scenes make this a plain
        subtraction.
        """
        world_yaw = tool_down_yaw(
            float(quat.x), float(quat.y))
        _origin, rpy = origin_in_world(self._scene)
        return world_yaw - float(rpy[2])

    def _live_arm_joints(self):
        with self._joint_lock:
            state = getattr(self, "_joint_state", None)
        if not state:
            return None
        by_name = dict(zip(state.name, state.position))
        try:
            return [float(by_name[n]) for n in JOINTS]
        except KeyError:
            return None

    def _target_in_container(self, map_xyz):
        from luggage_planning.geometry_view_generator import (
            point_inside_container_inner_box)
        world = self._map_to_world(list(map_xyz))
        return bool(point_inside_container_inner_box(world, self._scene))

    def _refine_atlas_seeds(self, pose, seeds, z_lift_m=0.0, lift_xyz=None):
        """Deterministic offline refine of atlas seeds onto the exact pose.

        KDL's random restarts make /compute_ik a lottery for this target
        class (2026-09-24 smokes: same seed/scene flapping between instant
        solutions and 1 s -31). scipy converges from these seeds in
        milliseconds, deterministically; the executor then FK-verifies the
        refined joints before submitting them as a MoveGroup joint goal.
        Unrefinable seeds are dropped.
        """
        try:
            from luggage_planning.offline_ik import (
                load_urdf, refine_to_pose)
            urdf = load_urdf(scene_tf_config=str(
                self.get_parameter("scene_tf_config").value or "") or None)
            path = self._offline_tcp_path(urdf)
            quat = (float(pose.orientation.x), float(pose.orientation.y),
                    float(pose.orientation.z), float(pose.orientation.w))
            if lift_xyz is None:
                lift_xyz = (0.0, 0.0, float(z_lift_m))
            target = (
                float(pose.position.x) + float(lift_xyz[0]),
                float(pose.position.y) + float(lift_xyz[1]),
                float(pose.position.z) + float(lift_xyz[2]))
            refined = []
            for seed in seeds:
                joints, info = refine_to_pose(
                    urdf, path, target, quat, seed)
                if joints is not None:
                    refined.append(joints)
                    self.get_logger().info(
                        "atlas seed refined pos_err=%s rot_err=%s"
                        % (info["pos_err_m"], info["rot_err_rad"]))
            return refined
        except Exception as exc:  # noqa: BLE001 - refine is best-effort
            self.get_logger().warning(
                "atlas seed refine unavailable (%s); raw seeds" % exc)
            return seeds

    @staticmethod
    def _offline_tcp_path(urdf):
        key = ("tcp_path", id(urdf))
        cached = _ATLAS_CACHE.get(key)
        if cached is None:
            cached = urdf.path_to("suction_contact_frame")
            _ATLAS_CACHE[key] = cached
        return cached

    def _cartesian_fallback_provider(self, segment_msg, live_joints):
        """Offline re-solve of a rejected cartesian leg (goal or polyline).

        Returns ``{"knots": [live, ...per-waypoint], "fk_path_len": m}`` or
        ``None``. The refine seeds from the live arm and warm-starts along
        the waypoint chain, so it selects the IK branch continuous with the
        current state -- the branch GetCartesianPath failed to hold
        (2026-09-27 insert: j6 drift 0.771 rad at fraction 0.244; box3
        transit carry: stalled 0.459 on the rim-riding diagonal while the
        walk converges along the whole chain). The executor densifies,
        re-checks the SAME excursion bar and sweeps occupancy before
        executing, so this stays fail-closed.
        """
        try:
            from luggage_planning.offline_ik import (
                load_urdf, refine_to_pose)
            urdf = load_urdf(scene_tf_config=str(
                self.get_parameter("scene_tf_config").value or "") or None)
            path = self._offline_tcp_path(urdf)
            pose = segment_msg.target_pose
            quat = (float(pose.orientation.x), float(pose.orientation.y),
                    float(pose.orientation.z), float(pose.orientation.w))
            chain = [
                (float(p.position.x), float(p.position.y), float(p.position.z))
                for p in (getattr(segment_msg, "waypoints", None) or [])]
            chain.append((float(pose.position.x), float(pose.position.y),
                          float(pose.position.z)))
            current = [float(v) for v in live_joints]
            start_fk = urdf.tcp(current, path)[:3, 3]
            from luggage_planning.joint_path import wrap_near
            from luggage_planning.occupancy_place_paths import _sample_polyline
            sampled = _sample_polyline(
                [tuple(float(v) for v in start_fk)] + chain, 0.04)[1:]
            knots = [list(current)]
            fk_len = 0.0
            prev = tuple(float(v) for v in start_fk)
            info = {"pos_err_m": None, "rot_err_rad": None}
            for point in sampled:
                joints, info = refine_to_pose(urdf, path, point, quat,
                                              seed=current)
                if joints is None:
                    self.get_logger().info(
                        "cartesian joint fallback refine failed at %s (%s)"
                        % (tuple(round(v, 3) for v in point), info))
                    return None
                joints = wrap_near(joints, current)
                fk = urdf.tcp(joints, path)[:3, 3]
                fk_len += float(
                    sum((float(fk[i]) - prev[i]) ** 2 for i in range(3))
                    ** 0.5)
                prev = tuple(float(v) for v in fk)
                knots.append(list(joints))
                current = joints
            self.get_logger().info(
                "cartesian joint fallback refined %s (%d waypoints) "
                "fk_len=%.3f pos_err=%s rot_err=%s"
                % (getattr(segment_msg, "name", "?"), len(knots) - 1, fk_len,
                   info["pos_err_m"], info["rot_err_rad"]))
            return {
                "knots": knots,
                "fk_path_len": fk_len,
                "pos_err_m": info.get("pos_err_m"),
                "rot_err_rad": info.get("rot_err_rad"),
            }
        except Exception as exc:  # noqa: BLE001 - provider boundary
            self.get_logger().warning(
                "cartesian joint fallback unavailable (%s)" % exc)
            return None

    def _verify_tcp(self, joints):
        """World TCP of ``joints`` from the installed URDF. Root stays ``world``."""
        from scipy.spatial.transform import Rotation
        from luggage_planning.offline_ik import load_urdf
        urdf = load_urdf(scene_tf_config=str(
            self.get_parameter("scene_tf_config").value or "") or None)
        transform = urdf.tcp(list(joints), self._offline_tcp_path(urdf))
        quat = Rotation.from_matrix(transform[:3, :3]).as_quat()
        return (
            [float(v) for v in transform[:3, 3]],
            [float(v) for v in quat],
        )

    def _handle_probe_segment_v2(self, request, response):
        from luggage_planning.motion_v2_service import handle_probe_v2
        if getattr(self, "_frame_runtime", None) is not None:
            from luggage_description.frame_contracts import ContractError
            try:
                admission = self._frame_runtime.admit_request(
                    str(getattr(request.segment, "request_id", "") or ""),
                    endpoint="/motion_planner/probe_motion_segment_v2")
            except ContractError as error:
                response.success = False
                response.reason_code = error.code
                response.message = "%s: %s" % (error.code, error.field)
                return response
        start = None
        joints = self._joint_positions()[0]
        if joints:
            start = list(joints)
        response = handle_probe_v2(
            self._executor_client, request.segment, self._scene_tf_hash,
            response, link=self._executor_client._link,
            start_joints=start)
        if getattr(self, "_frame_runtime", None) is not None and bool(
                getattr(response, "success", False)):
            from luggage_description.frame_contracts import ContractError
            try:
                self._frame_runtime.authorize_effect(
                    admission, str(getattr(request.segment, "request_id", "")
                                   or ""))
            except ContractError as error:
                response.success = False
                response.reason_code = error.code
                response.message = "%s: %s" % (error.code, error.field)
        return response

    def _admission_still_live(self, goal_request):
        """[ST09-I S5.7-3b] Mechanical liveness check; fail-closed."""
        import threading

        from luggage_msgs.srv import CheckExecutionAdmission

        client = getattr(self, "_admission_client", None)
        if client is None:
            client = self.create_client(
                CheckExecutionAdmission,
                "/trajectory_selector/check_execution_admission")
            self._admission_client = client
        if not client.wait_for_service(timeout_sec=5.0):
            return False, "ADMISSION_CHECK_UNAVAILABLE"
        request = CheckExecutionAdmission.Request()
        request.route_digest = str(
            getattr(goal_request, "route_digest", "") or "")
        request.certification_id = str(
            getattr(goal_request, "certification_id", "") or "")
        request.admission_map_revision = int(
            getattr(goal_request, "admission_map_revision", 0) or 0)
        request.scene_revision = str(
            getattr(goal_request.segment, "scene_revision", "") or "")
        request.leg_digest = str(
            getattr(goal_request, "admission_leg_digest", "") or "")
        request.leg_load_state = str(
            getattr(goal_request, "admission_load_state", "") or "")
        import time as _timing

        _t0 = _timing.monotonic_ns()
        event = threading.Event()
        future = client.call_async(request)
        future.add_done_callback(lambda _f: event.set())
        if not event.wait(timeout=5.0) or not future.done():
            return False, "ADMISSION_CHECK_UNAVAILABLE", round(
                (_timing.monotonic_ns() - _t0) / 1e6, 1)
        response = future.result()
        self._last_admission_check_ms = round(
            (_timing.monotonic_ns() - _t0) / 1e6, 1)
        if not bool(response.live):
            return False, str(response.reason_code
                              or "ADMISSION_REVOKED"), \
                self._last_admission_check_ms
        return True, "", self._last_admission_check_ms

    def _execute_plan_motion_v2(self, goal_handle):
        return run_legacy_motion(self._motion_owner, goal_handle, PlanMotionV2.Result,
            "PlanMotionV2", self._execute_plan_motion_v2_owned)

    def _execute_plan_motion_v2_owned(self, goal_handle):
        from luggage_planning.motion_v2_service import handle_plan_v2
        result = PlanMotionV2.Result()
        if getattr(self, "_frame_runtime", None) is not None:
            # Motion effect: the v2 chain is admitted end to end or refused.
            from luggage_description.frame_contracts import ContractError
            from luggage_description.runtime_action_readiness import certified_motion_scope
            goal = goal_handle.request
            scope = certified_motion_scope({
                "route_digest": str(goal.route_digest or ""),
                "certification_id": str(goal.certification_id or ""),
                "leg_digest": str(goal.admission_leg_digest or ""),
                "load_state": str(goal.admission_load_state or ""),
            })
            try:
                admission = self._frame_runtime.admit_request(
                    str(getattr(goal_handle.request.segment, "request_id", "")
                        or ""),
                    endpoint="/motion_planner/plan_motion_v2", scope=scope)
                self._frame_runtime.authorize_effect(
                    admission, str(
                        getattr(goal_handle.request.segment, "request_id", "")
                        or ""))
            except ContractError as error:
                goal_handle.abort()
                result.success = False
                result.message = "%s: %s" % (error.code, error.field)
                return result
        start = None
        joints = self._joint_positions()[0]
        if joints:
            start = list(joints)
        # [ST09-I S5.7-3b] execution-admission gate: when the goal
        # claims a certified route, the generation must STILL be live
        # before the first controller submission (and again for every
        # later leg -- each leg is its own goal). Mechanical check
        # only; the certifier side owns the verdict.
        if (str(getattr(goal_handle.request, "route_digest", "") or "")
                or str(getattr(
                    goal_handle.request, "certification_id", "") or "")):
            live, reason, _ms = self._admission_still_live(
                goal_handle.request)
            result.admission_check_ms = float(
                getattr(self, "_last_admission_check_ms", 0.0) or 0.0)
            if not live:
                goal_handle.abort()
                result.success = False
                result.message = reason
                return result
        handle_plan_v2(
            self._executor_client, goal_handle.request.segment,
            self._scene_tf_hash, result, self._prepare_occupancy,
            link=self._executor_client._link, current_joints=start,
            execute_timeout=float(self.get_parameter("execute_timeout").value))
        if not result.success:
            mismatch = (self._executor_client.last_boundary() or {}).get(
                "qp_start_state_mismatch")
            if mismatch:
                self.get_logger().error(
                    "QP_START_STATE_MISMATCH %s" % json.dumps(
                        mismatch, sort_keys=True))
        if result.success:
            goal_handle.succeed()
        else:
            goal_handle.abort()
        return result

    def _map_to_world(self, xyz):
        from luggage_description.scene_tf_publisher import rpy_to_quaternion
        from luggage_planning.motion_frame_contracts import map_container_point
        origin, rpy = origin_in_world(self._scene)
        return map_container_point(xyz, origin, rpy_to_quaternion(rpy))

    def _payload_wdh(self):
        """Occupancy-sweep payload box: measured geometry when synced."""
        wdh, source = resolve_payload_wdh(self._payload_measured, [
            float(self.get_parameter("payload_width").value),
            float(self.get_parameter("payload_depth").value),
            float(self.get_parameter("payload_height").value),
        ])
        self._payload_source = source
        self._payload_wdh_current = wdh
        return wdh

    def _exempt_for(self, segment, snapshot):
        """Landing-footprint exemption for the segment's in-hull waypoints.

        Relief, not a gate: any failure to derive it returns no exemption
        (the sweep then behaves like the old carry-only scope would).
        """
        waypoints = [(wp.position.x, wp.position.y, wp.position.z)
                     for wp in (getattr(segment, "waypoints", None) or [])]
        target = getattr(segment, "target_pose", None)
        yaw = 0.0
        if target is not None and hasattr(target, "position"):
            waypoints.append((target.position.x, target.position.y,
                              target.position.z))
            try:
                quat = target.orientation
                yaw = tool_down_yaw(quat.x, quat.y)
            except (AttributeError, TypeError, ValueError):
                yaw = 0.0
        try:
            mapped = [self._world_to_map(wp) for wp in waypoints]
            return exempt_footprint_locals(
                snapshot, mapped, self._payload_wdh(), yaw=yaw,
                arm_radius=float(self.get_parameter("arm_radius_m").value),
                inflate_m=float(self.get_parameter("inflate_m").value),
                margin_m=float(
                    self.get_parameter("occupancy_exempt_margin_m").value))
        except Exception:  # noqa: BLE001 - exemption must not block motion
            return []

    def _prepare_occupancy(self, segment):
        """Inject occupancy boxes and pin the executor sweep. Empty on success.

        Scope is ``occupancy_segments`` ("*" by default: insert, descend,
        retreat, place_exit and the staging segments are checked too, per
        placement.md "place motion through occupancy"). Waypoints inside
        the hull anchor a landing-footprint exemption so the slot's own
        support and inflated neighbours cannot block the insertion they
        exist for.
        """
        name = str(getattr(segment, "name", ""))
        if not occupancy_scope(
                self.get_parameter("occupancy_segments").value, name):
            self._executor_client.set_occupancy(None)
            return ""
        surface = self._surface_2d
        if surface is None:
            return ""
        freshness = float(self.get_parameter("occupancy_freshness_s").value)
        if (freshness > 0.0 and self._surface_recv is not None
                and (time.time() - self._surface_recv) > freshness):
            snap_try = OccupancySnapshot.from_surface_2d(
                surface, inflate_m=float(self.get_parameter("inflate_m").value))
            if snap_try.occupied_count() > 0:
                return "PLACE_PATH_INFEASIBLE occupancy stale"
        try:
            snapshot = OccupancySnapshot.from_surface_2d(
                surface,
                inflate_m=float(self.get_parameter("inflate_m").value))
        except OccupancyMismatch as exc:
            return str(exc)
        exempt = self._exempt_for(segment, snapshot)
        boxes = occupancy_collision_boxes(
            snapshot,
            max_objects=int(self.get_parameter("max_occ_objects").value),
            exempt=exempt)
        from luggage_description.frame_contracts import ContractError
        from luggage_description.scene_tf_publisher import rpy_to_quaternion
        from luggage_planning.motion_frame_contracts import (
            compose_orientation, map_container_point,
        )
        origin, rpy = origin_in_world(self._scene)
        container_quat = rpy_to_quaternion(rpy)
        world_boxes = []
        for box in boxes:
            try:
                world_boxes.append({
                    "id": box["id"],
                    "xyz": map_container_point(box["xyz"], origin, container_quat),
                    "size": box["size"],
                    "quat": compose_orientation(container_quat, box["quat"]),
                })
            except ContractError as exc:
                return exc.code
        if world_boxes:
            ok, message = self._scene_client.add_collision_boxes(
                world_boxes, frame_id="world")
            if not ok:
                return "PLACE_PATH_INFEASIBLE occupancy inject: %s" % message
            self._injected_ids = [box["id"] for box in world_boxes]
        self._executor_client.set_occupancy(
            snapshot, self._payload_wdh(),
            world_to_map=self._world_to_map,
            arm_radius=float(self.get_parameter("arm_radius_m").value),
            inflate_m=float(self.get_parameter("inflate_m").value),
            object_count=len(world_boxes),
            exempt_locals=exempt)
        return ""

    def _clear_occupancy(self):
        self._executor_client.set_occupancy(None)
        ids = list(self._injected_ids)
        self._injected_ids = []
        if ids:
            self._scene_client.remove_objects(ids)

    def _on_joint_state(self, msg):
        if set(JOINTS) <= set(msg.name):
            with self._joint_lock:
                self._joint_state = msg

    def _scene_summary(self):
        scene = self._scene_client.get_scene(
            PlanningSceneComponents.WORLD_OBJECT_GEOMETRY
            | PlanningSceneComponents.ROBOT_STATE
            | PlanningSceneComponents.ROBOT_STATE_ATTACHED_OBJECTS,
            timeout=3.0)
        return summarize_planning_scene(scene)

    def _occ_summary(self):
        surface = self._surface_2d
        if surface is None:
            return {"present": False}
        return {
            "present": True,
            "map_revision": surface.get("map_revision"),
            "geometry_hash": surface.get("geometry_hash"),
            "age_s": (None if self._surface_recv is None
                      else round(time.time() - self._surface_recv, 3)),
        }

    def _capture_failure(self, t_wall, name):
        """Freeze occ + source cloud + depth at failure time. Never raises.

        Writes only when MOTION_BOUNDARY_DUMP is set; the record always
        carries the occ summary and what was or was not captured.
        """
        try:
            if not bool(self.get_parameter("debug_capture").value):
                return {"enabled": False}
            dump_root = os.environ.get("MOTION_BOUNDARY_DUMP", "")
            if not dump_root:
                return {"enabled": True, "reason": "no_dump_root"}
            tag = "%d_%s" % (int(float(t_wall) * 1000.0), name)
            return write_failure_capture(
                dump_root, tag,
                surface=self._surface_2d,
                surface_age_s=(None if self._surface_recv is None
                               else round(time.time() - self._surface_recv,
                                          3)),
                cloud_msg=self._cap_cloud,
                depth_msg=self._cap_depth)
        except Exception as exc:  # noqa: BLE001 - dump path must not fail
            return {"error": str(exc)}

    def _emit_boundary(self, name, extra=None, success=True):
        record = {"name": str(name or ""), "t_wall": time.time()}
        record.update(self._executor_client.last_boundary() or {})
        record["payload_source"] = self._payload_source
        record["payload_wdh"] = list(self._payload_wdh_current)
        if extra:
            record.update(extra)
        if not success:
            record["planning_scene"] = self._scene_summary()
            record["occ"] = self._occ_summary()
            record["capture"] = self._capture_failure(record["t_wall"], name)
        path = write_boundary_dump(
            os.environ.get("MOTION_BOUNDARY_DUMP", ""), record)
        if path:
            record["dump"] = path
        try:
            self._boundary_pub.publish(
                String(data=json.dumps(record, default=str)))
        except Exception:  # noqa: BLE001 - dump path must not fail the motion
            pass
        return record

    def _joint_positions(self):
        with self._joint_lock:
            if self._joint_state is None:
                return None, None
            by_name = dict(zip(self._joint_state.name,
                               self._joint_state.position))
            by_vel = dict(zip(self._joint_state.name,
                              self._joint_state.velocity
                              if len(self._joint_state.velocity) else []))
            return ([float(by_name.get(j, 0.0)) for j in JOINTS],
                    [float(by_vel.get(j, 0.0)) for j in JOINTS])

    def _poses_config(self):
        path = str(self.get_parameter("robot_poses_config").value)
        if not path:
            from ament_index_python.packages import get_package_share_directory
            path = os.path.join(
                get_package_share_directory("luggage_description"),
                "config", "robot_poses.site.yaml")
        return load_poses_config(path), path

    # ------------------------------------------------------------------
    # ProbeMotionSegment (plan-only; no motion, no vacuum)

    def _handle_probe_segment(self, request, response):
        segment = request.segment
        response.fraction = -1.0
        response.moveit_error_code = 0
        if getattr(self, "_frame_runtime", None) is not None:
            from luggage_description.frame_contracts import ContractError
            try:
                self._frame_runtime.authorize_legacy_effect()
            except ContractError as error:
                response.success = False
                response.message = "%s: %s" % (error.code, error.field)
                return response
        if not self._executor_client.wait_ready(15.0):
            response.success = False
            response.message = "move_group not ready"
            return response
        # Probes see the same occupancy the executed segment would: scope,
        # landing exemption, injected boxes (plan-only, nothing moves).
        occ_err = self._prepare_occupancy(segment)
        if occ_err:
            self._clear_occupancy()
            response.success = False
            response.ik_ok = False
            response.message = occ_err
            return response
        try:
            start = self._joint_positions()[0]
            record = self._executor_client.probe_segment(segment, start)
        finally:
            self._clear_occupancy()
        response.ik_ok = bool(record.get("ik_ok"))
        fraction = record.get("fraction")
        response.fraction = -1.0 if fraction is None else float(fraction)
        response.success = bool(response.ik_ok)
        response.message = "ik_ok=%s fraction=%.3f" % (
            response.ik_ok, response.fraction)
        return response

    # ------------------------------------------------------------------
    # PlanMotion

    def _execute_plan_motion(self, goal_handle):
        return run_legacy_motion(self._motion_owner, goal_handle, PlanMotion.Result,
            "PlanMotion", self._execute_plan_motion_owned)

    def _execute_plan_motion_owned(self, goal_handle):
        segment = goal_handle.request.segment
        result = PlanMotion.Result()
        name = str(segment.name)
        if getattr(self, "_frame_runtime", None) is not None:
            # v1 motion cannot bypass profile admission.
            from luggage_description.frame_contracts import ContractError
            try:
                self._frame_runtime.authorize_legacy_effect()
            except ContractError as error:
                goal_handle.abort()
                result.success = False
                result.message = "%s: %s" % (error.code, error.field)
                self._emit_boundary(name, extra={"kind": "PlanMotion"},
                                    success=False)
                return result
        result.fraction = 0.0
        result.used_ompl_fallback = False
        result.moveit_error_code = 0
        result.settle_json = ""

        def feedback(stage, segment_name, fraction, note=""):
            fb = PlanMotion.Feedback()
            fb.stage = str(stage)
            fb.segment_name = str(segment_name)
            fb.fraction = float(fraction)
            goal_handle.publish_feedback(fb)
            if note:
                self.get_logger().info("segment %s: %s" % (segment_name, note))

        # Generous: first graph discovery inside this process can take
        # seconds even when move_group has been up the whole time.
        if not self._executor_client.wait_ready(timeout_sec=15.0):
            goal_handle.abort()
            result.success = False
            result.message = "move_group unavailable"
            self._emit_boundary(name, extra={"kind": "PlanMotion"}, success=False)
            return result

        try:
            occ_err = self._prepare_occupancy(segment)
            if occ_err:
                goal_handle.abort()
                result.success = False
                result.message = occ_err
                self._emit_boundary(
                    name, extra={"kind": "PlanMotion"}, success=False)
                return result
            exec_result = self._executor_client.execute_segment(
                segment, feedback_cb=feedback,
                execute_timeout=float(
                    self.get_parameter("execute_timeout").value),
                current_joints=self._joint_positions()[0],
                cancel_check=lambda: goal_handle.is_cancel_requested)
            result.fraction = float(exec_result.fraction)
            result.used_ompl_fallback = bool(exec_result.used_ompl_fallback)
            result.moveit_error_code = int(exec_result.moveit_error_code)
            ok = bool(exec_result.success)
            message = exec_result.message
            fraction = exec_result.fraction
            target = segment.target_pose.position
            self._emit_boundary(name, extra={
                "kind": "PlanMotion",
                "segment_type": str(segment.type),
                "target": [float(target.x), float(target.y), float(target.z)],
            }, success=ok)
        except Exception as exc:  # noqa: BLE001 - action boundary
            self.get_logger().error("segment %s raised: %s" % (name, exc))
            goal_handle.abort()
            result.success = False
            result.message = "executor raised: %s" % exc
            self._emit_boundary(name, extra={"kind": "PlanMotion"}, success=False)
            return result
        finally:
            self._clear_occupancy()

        if not ok:
            if goal_handle.is_cancel_requested:
                goal_handle.canceled()
            else:
                goal_handle.abort()
            result.success = False
            result.message = message
            return result

        settled, settle_diag = self._wait_settled(
            lambda: feedback("settling", name, fraction))
        result.settle_json = json.dumps(settle_diag, sort_keys=True)
        if not settled:
            goal_handle.abort()
            result.success = False
            result.message = "%s; settle timeout" % message
            return result

        if goal_handle.is_cancel_requested:
            goal_handle.canceled()
            result.success = False
            result.message = "%s; canceled after settle" % message
            return result

        goal_handle.succeed()
        result.success = True
        result.message = message
        return result

    def _named_pose_duration(self, current, target):
        cap = max(0.5, float(self.get_parameter("named_pose_duration").value))
        max_vel = max(0.1, float(self.get_parameter("named_pose_max_vel").value))
        if current is None:
            return cap
        max_delta = max(
            abs(float(a) - float(b)) for a, b in zip(current, target))
        return max(1.0, min(cap, max_delta / max_vel))

    def _wait_settled(self, pulse, timeout=None):
        timeout = timeout or float(self.get_parameter("settle_timeout").value)
        tracker = SettleTracker(
            float(self.get_parameter("settle_vel_tol").value),
            float(self.get_parameter("settle_hold_time").value))
        timer = ClockTimeout(self.get_clock(), timeout)
        while not timer.done():
            time.sleep(0.05)
            positions, velocities = self._joint_positions()
            if positions is None:
                continue
            pos_d = dict(zip(JOINTS, positions))
            vel_d = dict(zip(JOINTS, velocities or [0.0] * len(JOINTS)))
            tracker.update(timer.elapsed(), vel_d, pos_d)
            if tracker.settled_at is not None:
                return True, tracker.diagnostics()
            pulse()
        return tracker.settled_at is not None, tracker.diagnostics()

    # ------------------------------------------------------------------
    # GoToRobotPose (named joint pose via FJT)

    def _execute_goto_pose(self, goal_handle):
        return run_legacy_motion(self._motion_owner, goal_handle, GoToRobotPose.Result,
            "GoToRobotPose", self._execute_goto_pose_owned)

    def _execute_goto_pose_owned(self, goal_handle):
        result = GoToRobotPose.Result()
        requested = str(goal_handle.request.pose_name)
        if getattr(self, "_frame_runtime", None) is not None:
            # FJT dispatch is a motion effect; v1 cannot bypass admission.
            from luggage_description.frame_contracts import ContractError
            try:
                self._frame_runtime.authorize_legacy_effect()
            except ContractError as error:
                goal_handle.abort()
                result.success = False
                result.message = "%s: %s" % (error.code, error.field)
                return result

        def feedback(stage, remaining_error=0.0):
            fb = GoToRobotPose.Feedback()
            fb.stage = str(stage)
            fb.remaining_error = float(remaining_error)
            goal_handle.publish_feedback(fb)

        positions, _ = self._joint_positions()
        path = ""
        pose_name = requested
        try:
            config, path = self._poses_config()
            pose_name = resolve_pose_name(
                requested, config,
                param_override=str(
                    self.get_parameter("default_observe_pose").value))
            target = plan_goto_joints(pose_name, config, positions)
        except Exception as exc:  # noqa: BLE001 - action boundary
            goal_handle.abort()
            result.success = False
            result.message = str(exc)
            return result
        if target is None:
            goal_handle.succeed()
            result.success = True
            result.already_there = True
            result.message = "already at %s (current joints)" % pose_name
            return result
        target = list(target)

        positions, _ = self._joint_positions()
        if positions is not None:
            target = [
                _wrap_near(cur, tgt) for cur, tgt in zip(positions, target)]
        if positions is not None and max(
                abs(a - b) for a, b in zip(positions, target)) < 0.02:
            goal_handle.succeed()
            result.success = True
            result.already_there = True
            result.message = "already at %s" % pose_name
            return result

        if not self._fjt.wait_for_server(timeout_sec=5.0):
            goal_handle.abort()
            result.success = False
            result.message = "FJT action server unavailable"
            return result

        feedback("executing")
        goal = FollowJointTrajectory.Goal()
        traj = JointTrajectory()
        traj.joint_names = list(JOINTS)
        start = list(positions) if positions is not None else list(target)
        p0 = JointTrajectoryPoint()
        p0.positions = start
        p0.velocities = [0.0] * len(JOINTS)
        p0.time_from_start = Duration(sec=0, nanosec=0)
        p1 = JointTrajectoryPoint()
        p1.positions = target
        p1.velocities = [0.0] * len(JOINTS)
        duration = self._named_pose_duration(start, target)
        sec = int(duration)
        p1.time_from_start = Duration(
            sec=sec, nanosec=int((duration - sec) * 1e9))
        traj.points = [p0, p1]
        goal.trajectory = traj
        goal.goal_time_tolerance = Duration(sec=2, nanosec=0)

        event = threading.Event()
        future = self._fjt.send_goal_async(goal)
        future.add_done_callback(lambda _f: event.set())
        if not event.wait(10.0):
            goal_handle.abort()
            result.success = False
            result.message = "FJT goal send timeout"
            return result
        handle = future.result()
        if not handle.accepted:
            goal_handle.abort()
            result.success = False
            result.message = "FJT goal rejected"
            return result

        result_event = threading.Event()
        result_future = handle.get_result_async()
        result_future.add_done_callback(lambda _f: result_event.set())
        reached, wait_reason = wait_event(
            result_event, duration + 60.0, clock=self.get_clock())
        if not reached:
            handle.cancel_goal()
            goal_handle.abort()
            result.success = False
            extra = " (%s)" % wait_reason if wait_reason else ""
            result.message = "FJT execution timeout%s" % extra
            return result
        wrapped = result_future.result()
        if wrapped.status != GoalStatus.STATUS_SUCCEEDED:
            self.get_logger().warn(
                "FJT named pose failed (%s %s); MoveIt joint fallback"
                % (wrapped.status, wrapped.result.error_code))
            moveit = self._executor_client.execute_joints(
                target, execute_timeout=float(
                    self.get_parameter("execute_timeout").value),
                current_joints=positions)
            extra = {
                "kind": "GoToRobotPose",
                "pose_name": pose_name,
                "method": "fjt_then_moveit",
                "fjt_status": int(wrapped.status),
                "fjt_error_code": int(wrapped.result.error_code),
                "fjt_trajectory": robot_traj_to_dict(traj),
                "start_joints": list(start),
                "target_joints": list(target),
            }
            if not moveit.success:
                goal_handle.abort()
                result.success = False
                result.message = "FJT status=%s error_code=%s; %s" % (
                    wrapped.status, wrapped.result.error_code, moveit.message)
                self._emit_boundary(
                    "goto_%s" % pose_name, extra=extra, success=False)
                return result
            settled, _diag = self._wait_settled(
                lambda: feedback("settling"))
            if not settled:
                goal_handle.abort()
                result.success = False
                result.message = "reached %s via MoveIt but settle timeout" % pose_name
                self._emit_boundary(
                    "goto_%s" % pose_name, extra=extra, success=False)
                return result
            goal_handle.succeed()
            result.success = True
            result.already_there = False
            result.message = "reached %s (MoveIt joint fallback)" % pose_name
            self._emit_boundary(
                "goto_%s" % pose_name, extra=extra, success=True)
            return result

        extra = {
            "kind": "GoToRobotPose",
            "pose_name": pose_name,
            "method": "fjt",
            "fjt_trajectory": robot_traj_to_dict(traj),
            "start_joints": list(start),
            "target_joints": list(target),
        }
        settled, _diag = self._wait_settled(
            lambda: feedback("settling"))
        if not settled:
            goal_handle.abort()
            result.success = False
            result.message = "reached %s but settle timeout" % pose_name
            self._emit_boundary(
                "goto_%s" % pose_name, extra=extra, success=False)
            return result

        goal_handle.succeed()
        result.success = True
        result.already_there = False
        result.message = "reached %s" % pose_name
        self._emit_boundary(
            "goto_%s" % pose_name, extra=extra, success=True)
        return result


def main(argv=None):
    rclpy.init(args=argv)
    node = MotionPlannerNode()
    executor = MultiThreadedExecutor()
    executor.add_node(node)
    try:
        executor.spin()
    except (KeyboardInterrupt, ExternalShutdownException):
        pass
    finally:
        node.destroy_node()
        rclpy.shutdown()


if __name__ == "__main__":
    main()
