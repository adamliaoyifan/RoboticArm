"""Hindsight chain table: would seed-driven selection have picked a
same-branch (slot, heading) for the boxes that failed in the 2026-10-12/13
yaw180 runs?

For each recorded failed box: take its intended slot contact (container
frame) and heading, query the (rebuilt, directed) deploy_update atlas for
portal/slot branch pairing via seed_chain, and report same-branch plus the
best pair. This is the P4 "prophecy vs fact" table.
"""
from __future__ import division

import json
import math
import os
import sys

REPO = os.path.normpath(os.path.join(os.path.dirname(__file__), ".."))
EV = os.path.join(
    REPO, "docs/status/evidence/base_container_tf")

RUNS = [
    ("2026-10-12_yaw180_atlas_pack", "atlas"),
    ("2026-10-13_yaw180_hullshadow_pack/attempt2", "hullshadow"),
    ("2026-10-13_yaw180_wristyaw_pack", "wristyaw"),
]

# World yaw of the box each run actually selected (ledger yaw_selected).
# Container heading = world_yaw + pi (container yaw pi in world).
CONTAINER_WORLD_YAW = math.pi


def world_to_container(p):
    return (-(p[0] + 1.5), 0.6 - p[1], p[2])


def main():
    import yaml
    from luggage_planning.atlas_runtime import (
        apply_query_semantics, load_runtime_atlas)
    from luggage_planning.offline_ik import default_urdf_xacro, load_urdf
    from luggage_planning.seed_chain import chain_report

    cfg = yaml.safe_load(open(os.path.join(
        REPO, "src/luggage_planning/config/atlas_runtime_deploy_update.yaml")))
    cfg = dict(cfg)
    cfg["hash_policy"] = "warn"  # offline URDF expansion hash differs
    atlas, meta = load_runtime_atlas(
        cfg, box_size=[0.476, 0.324, 0.218])
    print("atlas loaded:", "ok" if atlas is not None else None,
          (meta or {}).get("reason"))
    if atlas is None:
        return 1
    urdf = load_urdf(
        xacro_path=default_urdf_xacro(),
        scene_tf_config=os.path.join(
            REPO, "src/luggage_description/config/scene_tf_deploy_update.yaml"))
    path = urdf.path_to("suction_contact_frame")
    container_in_world = ((-1.5, 0.6, 0.0), (0.0, 0.0, math.pi))

    # Door-side anchor INSIDE the atlas grid (grid starts at -0.745;
    # the outside staging is out-of-bounds and carries no seeds).
    portal = (-0.745 + 0.075, -0.265, 1.35)
    rows = []
    for run, tag in RUNS:
        ledger = os.path.join(EV, run, "ledger.jsonl")
        if not os.path.isfile(ledger):
            print("skip", run)
            continue
        for line in open(ledger):
            rec = json.loads(line)
            pw = (rec.get("pose_planned_world") or {}).get("position")
            if not pw:
                continue
            # ledger yaw_selected is DEGREES (0.0 / 89.99 / 179.99)
            world_yaw = math.radians(float(rec.get("yaw_selected") or 0.0))
            heading_container = world_yaw + CONTAINER_WORLD_YAW
            # slot contact = box top: center z + height/2
            contact = world_to_container(
                (pw[0], pw[1], pw[2] + 0.5 * 0.2175))
            report = chain_report(
                atlas, urdf, path, contact, portal, heading_container,
                container_in_world)
            rows.append({
                "run": tag, "seq": rec.get("seq"),
                "fail": rec.get("fail_code") or "PLACED",
                "slot_container": [round(v, 3) for v in contact[:2]],
                "heading_world_deg": round(float(rec.get("yaw_selected") or 0.0), 1),
                "same_branch": report["same_branch"],
                "gap_rad": (None if report["branch_gap_rad"] is None
                            else round(report["branch_gap_rad"], 3)),
                "n_slot": report["n_slot_seeds"],
                "n_portal": report["n_portal_seeds"],
                "reason": report["reason"],
                "slot_status": report["slot_status"],
            })

    out_dir = os.path.join(
        EV, "2026-10-13_seed_chain")
    os.makedirs(out_dir, exist_ok=True)
    with open(os.path.join(out_dir, "hindsight_chain_table.json"), "w") as fh:
        json.dump(rows, fh, indent=1)
    for row in rows:
        print("%-10s seq%d %-22s yaw%6.1f  same_branch=%-5s gap=%-6s "
              "seeds %s/%s %s %s" % (
                  row["run"], row["seq"], row["fail"],
                  row["heading_world_deg"], row["same_branch"],
                  row["gap_rad"], row["n_slot"], row["n_portal"],
                  row["slot_status"] or "", row["reason"]))
    print("wrote", out_dir)


if __name__ == "__main__":
    sys.exit(main())
