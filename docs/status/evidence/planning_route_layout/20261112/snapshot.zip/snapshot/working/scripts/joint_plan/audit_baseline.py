#!/usr/bin/env python3
"""Record source/atlas identity and deterministic ST-0 tests; never launch ROS.

Run after sourcing ROS Humble and the workspace. An identity match is NOT
qualification of the historical deploy_update atlas: the user requires new
validation before it may guide the joint planner.
"""
import argparse
import hashlib
import importlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import time
import traceback


ROOT = Path(__file__).resolve().parents[2]
PACKAGES = ("luggage_planning", "luggage_description", "luggage_perception",
            "luggage_packing")
TESTS = (
    "src/luggage_planning/test/test_atlas_runtime.py",
    "src/luggage_perception/test/test_suction_patch_evaluator.py",
    "src/luggage_planning/test/test_placement_prior_pick.py",
)


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--run-tests", action="store_true")
    args = parser.parse_args()
    output = args.output.resolve()
    # A run is immutable: never overwrite a prior failure or pass.
    output.mkdir(parents=True, exist_ok=False)
    paths = [str(ROOT)] + [str(ROOT / "src" / name) for name in PACKAGES]
    for path in reversed(paths):
        sys.path.insert(0, path)
    env = dict(os.environ)
    env["PYTHONPATH"] = os.pathsep.join(paths + [env.get("PYTHONPATH", "")])
    # These are pure unit tests. ROS launch_testing eagerly imports unrelated
    # modules from both test directories, which contain same-named files.
    # Keep that plugin out of this runner; native/launch gates use other runners.
    env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    report = {
        "scope": "ST-0 offline baseline; no runtime or trajectory qualification",
        "command": sys.argv,
        "python": sys.version,
        "platform": platform.platform(),
        "revision": subprocess.check_output(
            ["git", "rev-parse", "HEAD"], cwd=ROOT, text=True).strip(),
        "dirty": subprocess.check_output(
            ["git", "status", "--porcelain"], cwd=ROOT, text=True).splitlines(),
        "started_ns": time.time_ns(),
        "ros_distro": env.get("ROS_DISTRO"),
        "ament_prefix_path": env.get("AMENT_PREFIX_PATH"),
        "pytest_disable_plugin_autoload": env["PYTEST_DISABLE_PLUGIN_AUTOLOAD"],
        "imports": {}, "errors": [],
        "atlas_qualification": "not_evaluated_user_requires_revalidation",
        "teardown": "not_needed_no_stack_started",
    }
    try:
        import yaml
        from luggage_planning import atlas_runtime
        for name in ("luggage_planning.atlas_runtime",
                     "luggage_perception.suction_patch_evaluator",
                     "luggage_planning.placement_prior_pick"):
            module = importlib.import_module(name)
            path = Path(module.__file__).resolve()
            report["imports"][name] = {"path": str(path), "sha256": sha256(path)}
        scene = ROOT / "src/luggage_description/config/scene_tf_deploy_update.yaml"
        meta = ROOT / ("src/luggage_planning/data/reachability_atlas_deploy_update/"
                       "s20_container_collision_aware.yaml")
        npz = meta.with_suffix(".npz")
        dependencies = yaml.safe_load(meta.read_text())["dependencies"]
        report["scene"] = {
            "path": str(scene), "sha256": sha256(scene),
            "scene_tf_hash": atlas_runtime.compute_scene_tf_hash(str(scene)),
            "reachability_scene_hash": atlas_runtime.compute_reachability_scene_hash(str(scene)),
        }
        report["historical_atlas"] = {
            "metadata": str(meta), "metadata_sha256": sha256(meta),
            "npz": str(npz), "npz_sha256": sha256(npz),
            "dependencies": dependencies,
            "scene_identity_matches": all(
                report["scene"][key] == dependencies.get(key)
                for key in ("scene_tf_hash", "reachability_scene_hash")),
            "live_urdf_checked": False,
            "collision_revalidated": False,
            "eligible_for_joint_planning": False,
        }
    except Exception:
        failure = traceback.format_exc()
        (output / "audit-error.txt").write_text(failure)
        report["errors"].append("audit-error.txt")
    if args.run_tests:
        command = [sys.executable, "-m", "pytest", "-q", *TESTS,
                   "--junitxml=" + str(output / "junit.xml")]
        started = time.monotonic()
        with (output / "pytest.log").open("w") as log:
            result = subprocess.run(command, cwd=ROOT, env=env,
                                    stdout=log, stderr=subprocess.STDOUT)
        report["tests"] = {"command": command, "returncode": result.returncode,
                           "elapsed_s": time.monotonic() - started,
                           "log": "pytest.log", "junit": "junit.xml"}
    report["finished_ns"] = time.time_ns()
    report["outcome"] = ("pass" if not report["errors"] and
                         report.get("tests", {}).get("returncode", 0) == 0
                         else "incomplete")
    (output / "manifest.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"output": str(output), "outcome": report["outcome"],
                      "atlas_qualification": report["atlas_qualification"]}))
    return 0 if report["outcome"] == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
