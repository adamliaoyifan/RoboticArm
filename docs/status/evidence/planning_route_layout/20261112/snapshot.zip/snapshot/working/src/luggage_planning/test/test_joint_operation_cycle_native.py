"""Actual production owners/native ports/host Action; synthetic actuator boundary.

The optical fixture is an explicitly synthetic overhead ray source. It is not
wrist-sensor/deploy_update qualification. No Gazebo or hardware is addressed.
"""
from pathlib import Path
from types import SimpleNamespace
import copy
import importlib.util
import json
import math
import os
import threading
import time

import numpy as np
import pytest

from test_joint_operation_preparation_native import prepare_stack,native_stack
from test_joint_operation_observer_native import observer_owner

pytestmark=[pytest.mark.skipif(not os.environ.get('JOINT_NATIVE_ENDPOINT_EXECUTABLE'),
    reason='explicit native whole-operation gate'),
    pytest.mark.parametrize('prepare_stack',['observer'],indirect=True)]


def wait_for(predicate,timeout=5.):
    end=time.monotonic()+timeout
    while time.monotonic()<end:
        if predicate():return
        time.sleep(.005)
    assert predicate(),'bounded whole-operation fixture condition did not occur'


def completed(future,timeout=30.):
    wait_for(future.done,timeout)
    return future.result()


@pytest.fixture
def cycle(prepare_stack,request):
    import rclpy
    from builtin_interfaces.msg import Time
    from rosgraph_msgs.msg import Clock
    from sensor_msgs.msg import JointState
    from std_msgs.msg import Header
    from sensor_msgs_py.point_cloud2 import create_cloud_xyz32
    from rclpy.parameter import Parameter
    from rclpy.executors import MultiThreadedExecutor
    from rclpy.callback_groups import ReentrantCallbackGroup
    from rclpy.action import ActionClient,ActionServer
    from rclpy.serialization import serialize_message
    from moveit_msgs.action import ExecuteTrajectory
    from moveit_msgs.srv import ApplyPlanningScene,GetMotionPlan
    from luggage_msgs.action import ExecuteJointOperationV2
    from luggage_msgs.srv import VacuumCommandV2
    from uld_occ_observer.srv import IntegrateObservation
    from luggage_planning.attachment_frame_adapters import handle_vacuum_command_v2
    from luggage_planning.joint_operation_contracts import OPERATION_JOINTS
    from luggage_planning.placement_prior_contracts import Transform
    from luggage_planning.place_service import pose_message
    from test_joint_operation_endpoints_native import robot_fixture

    f=prepare_stack
    directory=f.directory/request.node.name;directory.mkdir()
    original_scene=copy.deepcopy(f.state.scene)
    query=copy.deepcopy(f.request);query.request_id=request.node.name
    prepared=f.call(query)
    assert prepared.success,prepared.reason
    plan=f.root.issued.lookup(prepared.plan.plan_digest)
    source=Path(__file__).parents[1]/'scripts/motion_planner_node.py'
    spec=importlib.util.spec_from_file_location('whole_operation_motion_host',source)
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    xml,srdf=robot_fixture()
    params=dict(scene_tf_config=str(Path('src/luggage_description/config/scene_tf_deploy_update.yaml').resolve()),
        atlas_enabled=False,debug_capture=False,enable_joint_operation=True,use_sim_time=True,
        frame_scene_revision='scene',robot_description=xml,robot_description_semantic=srdf,
        container_translation=[0.,0.,0.],container_quaternion_xyzw=[0.,0.,0.,1.],
        observer_geometry_file=str(f.observer.geometry),observer_config_file=str(f.observer.config),
        geometric_slot_limit=2048,operation_state_file=str(directory/'owner.json'),
        operation_evidence_dir=str(directory/'operation'))
    node=module.MotionPlannerNode(context=f.owner.context,
        parameter_overrides=[Parameter(k,value=v) for k,v in params.items()])
    runtime=node._joint_operation
    state=SimpleNamespace(q=tuple(query.start_joints),goals=[],vacuum=[],planning_calls=0,
        sealed=False,released_box=None,released_size=None,stop=threading.Event(),failure=None,
        mode='success',cancel_requests=0,sequence=0)
    lock=threading.RLock()
    records=[]
    def record(name,message):
        raw=message if isinstance(message,bytes) else serialize_message(message)
        with lock:
            file='%04d_'%len(records)+name
            (directory/file).write_bytes(raw);records.append(file)
    group=ReentrantCallbackGroup()
    clock=node.create_publisher(Clock,'/clock',10)
    joints=node.create_publisher(JointState,'/joint_states',10)
    camera_client=node.create_client(IntegrateObservation,'/uld_occ_observer/integrate_observation')
    def apply_scene(req,res):
        record('apply_scene_request.cdr',req)
        scene=copy.deepcopy(f.state.scene)
        for obj in req.scene.world.collision_objects:
            scene.world.collision_objects=[old for old in scene.world.collision_objects if old.id!=obj.id]
            if obj.operation!=obj.REMOVE:scene.world.collision_objects.append(copy.deepcopy(obj))
        for obj in req.scene.robot_state.attached_collision_objects:
            scene.robot_state.attached_collision_objects=[old for old in scene.robot_state.attached_collision_objects
                                                          if old.object.id!=obj.object.id]
            if obj.object.operation!=obj.object.REMOVE:scene.robot_state.attached_collision_objects.append(copy.deepcopy(obj))
        if req.scene.allowed_collision_matrix.entry_names:
            scene.allowed_collision_matrix=copy.deepcopy(req.scene.allowed_collision_matrix)
        scene.robot_state.joint_state.position=list(state.q)
        f.state.scene=scene
        res.success=True
        record('apply_scene_response.cdr',res)
        return res
    def tool(_):
        sample=runtime.ports.joints()
        tcp=Transform.from_matrix(f.root.model.urdf.tcp(sample.positions,f.root.model.path))
        return dict(contract_version=2,kind='pose',frame_id='world',length_unit='m',
            stamp_ns=sample.stamp_ns,time_basis='acquisition',scene_revision='scene',
            request_id=plan.identity.request_id,reference='suction_contact_frame',
            orientation_semantics='tool_quaternion',position=tcp.translation,quaternion_xyzw=tcp.quaternion_xyzw)
    class Actuator:
        last_attach_record=None
        def attach(self,payload):
            self.last_attach_record=payload['attach_record'];state.sealed=True
            return True,'synthetic sealed'
        def detach(self,payload):
            from luggage_planning.attachment_frame_contracts import compose_box_world
            current=tool(None)
            xyz,quat=compose_box_world(self.last_attach_record,current['position'],current['quaternion_xyzw'])
            # Reference synthetic world only. The online path receives rendered
            # optical rays, not this actuator-derived box pose or a planned slot.
            state.released_box=Transform((xyz[0],xyz[1],xyz[2]-.05),quat)
            state.released_size=tuple(self.last_attach_record['size_wdh'])
            state.sealed=False
            record('reference_released_world.json',json.dumps(dict(position=state.released_box.translation,
                quaternion=quat,size=state.released_size,source='synthetic actuator reference, never online input')).encode())
            return True,'synthetic released'
    actuator=Actuator()
    def vacuum(req,res):
        state.vacuum.append(req.enable)
        record('vacuum_request.cdr',req)
        response=handle_vacuum_command_v2(req,res,scene_revision='scene',generation=f.domain.generation,
            resolve_tool=tool,backend=actuator,geometry_policy=f.root.limits)
        record('vacuum_response.cdr',response)
        return response
    def forbidden_planning(req,res):
        state.planning_calls+=1
        res.error_code.val=-1
        return res
    def controller(handle):
        record('controller_goal.cdr',handle.request)
        state.goals.append(copy.deepcopy(handle.request))
        state.q=tuple(handle.request.trajectory.joint_trajectory.points[-1].positions)
        f.state.scene.robot_state.joint_state.position=list(state.q)
        wait_for(lambda:node._joint_state is not None and
            tuple(node._joint_state.position)==state.q and
            node._joint_state.header.stamp.sec*10**9+node._joint_state.header.stamp.nanosec>=runtime.motion._active.dispatch_stamp_ns)
        handle.succeed()
        result=ExecuteTrajectory.Result();result.error_code.val=1
        record('controller_result.cdr',result)
        return result
    services=[node.create_service(ApplyPlanningScene,'/apply_planning_scene',apply_scene,callback_group=group),
        node.create_service(VacuumCommandV2,'/vacuum/command_v2',vacuum,callback_group=group),
        node.create_service(GetMotionPlan,'/plan_kinematic_path',forbidden_planning,callback_group=group)]
    controller_server=ActionServer(node,ExecuteTrajectory,'/execute_trajectory',controller,callback_group=group)
    client=ActionClient(node,ExecuteJointOperationV2,'/joint_operation/execute',callback_group=group)
    executor=MultiThreadedExecutor(context=f.owner.context,num_threads=8);executor.add_node(node)
    worker=threading.Thread(target=executor.spin,daemon=True);worker.start()
    base_xy=np.arange(-4.,4.001,.04,dtype=np.float32)
    base_points=np.array([(x,-y,1.8) for x in base_xy for y in base_xy],dtype=np.float32)
    def render():
        points=base_points.copy()
        box=state.released_box
        if box is None:return points
        # Exact reference ray/OBB intersection; preserve occlusion instead of
        # publishing ground rays through the newly released synthetic cargo.
        origin=np.array((0.,0.,2.))
        direction=points*np.array((1.,-1.,-1.))
        from scipy.spatial.transform import Rotation
        inverse_rotation=Rotation.from_quat(box.quaternion_xyzw).as_matrix().T
        local_origin=inverse_rotation@(origin-np.asarray(box.translation))
        local_direction=direction@inverse_rotation.T
        half=np.array(state.released_size)/2
        with np.errstate(divide='ignore',invalid='ignore'):
            t1=(-half-local_origin)/local_direction;t2=(half-local_origin)/local_direction
        entry=np.max(np.minimum(t1,t2),axis=1);exit=np.min(np.maximum(t1,t2),axis=1)
        hit=(entry>=0)&(entry<=1)&(exit>=entry)
        points[hit]*=entry[hit,None]
        return points
    def sensors():
        began=time.monotonic();last_camera=-1.
        try:
            while not state.stop.wait(.01):
                elapsed=time.monotonic()-began
                stamp=12_000_000_000+int(elapsed*1e9)
                time_message=Time(sec=stamp//10**9,nanosec=stamp%10**9)
                clock.publish(Clock(clock=time_message))
                message=JointState(header=Header(stamp=time_message),name=list(OPERATION_JOINTS),position=list(state.q))
                joints.publish(message)
                f.state.scene.robot_state.joint_state=copy.deepcopy(message)
                if elapsed-last_camera<.2:continue
                last_camera=elapsed;state.sequence+=1
                cloud=create_cloud_xyz32(Header(stamp=time_message,frame_id='optical'),render())
                observation=IntegrateObservation.Request(sensor_id='synthetic_depth',
                    observation_id='operation-view-'+str(state.sequence),clock_domain='ros',
                    geometry_hash=f.request.geometry_hash,epoch=f.observer.epoch,cloud=cloud)
                observation.uld_from_optical.header=Header(stamp=time_message,frame_id='container_link')
                observation.uld_from_optical.child_frame_id='optical'
                observation.uld_from_optical.transform.translation.z=2.
                observation.uld_from_optical.transform.rotation.x=1.
                observation.uld_from_optical.transform.rotation.w=0.
                record('camera_observation.cdr',observation)
                reply=completed(camera_client.call_async(observation),5.)
                record('camera_result.cdr',reply)
                assert reply.receipt.status=='INTEGRATED',reply.receipt.status
        except Exception as error:
            state.failure=str(error)
            record('sensor_failure.json',json.dumps(dict(reason=str(error))).encode())
    sensor=threading.Thread(target=sensors,daemon=True)
    try:
        assert client.wait_for_server(timeout_sec=5.)
        for c in [camera_client,runtime.ports.apply_client,runtime.ports.vacuum_client,
                  runtime.ports.scene_client,runtime.ports.check_client,
                  runtime.ports.contacts.retain_client,runtime.ports.contacts.check_client]:
            assert c.wait_for_service(timeout_sec=5.)
        sensor.start()
        wait_for(lambda:node._joint_state is not None and node.get_clock().now().nanoseconds>=12_000_000_000)
        goal=ExecuteJointOperationV2.Goal(plan=prepared.plan,detection=query.detection,
            top_domain=f.messages[2],budget_s=30.)
        record('execute_goal.cdr',goal)
        yield SimpleNamespace(f=f,node=node,runtime=runtime,client=client,goal=goal,plan=plan,
            state=state,directory=directory,record=record)
    finally:
        state.stop.set()
        if sensor.ident is not None:sensor.join(timeout=6.)
        executor.shutdown(timeout_sec=5.);worker.join(timeout=5.)
        record('teardown.json',json.dumps(dict(sensor_joined=not sensor.is_alive(),
            executor_joined=not worker.is_alive(),sensor_failure=state.failure,
            sealed=state.sealed,controller_goals=len(state.goals),vacuum_requests=state.vacuum,
            global_planner_calls=state.planning_calls)).encode())
        assert not sensor.is_alive() and not worker.is_alive()
        client.destroy();controller_server.destroy()
        node.destroy_node()
        f.state.scene=original_scene


def test_actual_complete_o_operation_returns_observed_success(cycle):
    c=cycle
    handle=completed(c.client.send_goal_async(c.goal))
    assert handle.accepted
    result=completed(handle.get_result_async(),40.)
    c.record('action_result.cdr',result.result)
    assert result.result.success,result.result.reason
    assert result.result.outcome=='COMPLETE' and not result.result.may_have_payload
    assert result.result.motion_terminal and result.result.final_map_source.bound
    assert len(c.state.goals)==6 and c.state.vacuum==[True,False]
    assert c.state.planning_calls==0 and not c.state.sealed
    assert c.node._motion_owner.snapshot()['active'] is None
    assert c.state.failure is None
    for index,goal in enumerate(c.state.goals):
        expected=c.goal.plan.legs[index].trajectory.trajectory
        from luggage_description.ros_frame_bindings.joints import joints_from_message
        # The exact original plan trajectory is already encoded in the typed
        # action; compare every controller knot/derivative and time field.
        actual=goal.trajectory.joint_trajectory
        assert list(actual.joint_names)==list(expected.joint_names)
        assert len(actual.points)==len(expected.points)
        for a,b in zip(actual.points,expected.points):
            assert a==b
